CREATE PROCEDURE `Select_Need_Send_Message_Proc`(`TWBH` VARCHAR(50))
  BEGIN
  SELECT 
    ITEM_TWBH,
    REPLACE(ITEM_FSYH,';',',')  AS ITEM_FSYH,
    CONCAT("http://121.40.255.15:8080/Z22629",    SUBSTRING(
        item_tp,
        INSTR(item_tp, '"path":"/') + 8,
        CHAR_LENGTH(item_tp) - INSTR(item_tp, '"path":"/') - 10
      )
    ) AS ITEM_TP,
    ITEM_NR,
    ITEM_TITLE FROM `tlk_twxx` WHERE ITEM_TWBH = TWBH ;
END