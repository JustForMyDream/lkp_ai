CREATE PROCEDURE `Insert_Send_Message_To_User_By_code`(`openid0` VARCHAR(50), `mcode` VARCHAR(50))
  BEGIN
      
      DECLARE err INT DEFAULT 1;#声明一个整形变量err，默认值是1
      DECLARE TID VARCHAR(20);
      DECLARE id0 VARCHAR(50);
      DECLARE l_last_sale INT DEFAULT 0;
      DECLARE sale_csr CURSOR FOR   
      SELECT id   FROM  tlk_TSXX WHERE item_mgstate=1 and ITEM_MGKIND=0 AND NOW() BETWEEN item_fromdate AND item_todate
      AND ITEM_MGCODE=mcode
      AND id NOT IN (SELECT ITEM_MID  FROM tlk_YHXX
      WHERE item_openid=openid0);  
      DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_last_sale=1;  
      DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET err=0;#当sqlexception handler捕捉到异常时，设置err=0           
      START TRANSACTION;    
        OPEN sale_csr;
           sale_loop:LOOP
           FETCH sale_csr INTO id0;
           IF l_last_sale THEN
               LEAVE sale_loop;               
           END IF;                   
          SET TID= CONCAT(DATE_FORMAT(NOW(),'%Y%m%d%H%m%s'),'MID',Generate_Rand_String_Fun(4));  
          INSERT INTO tlk_yhxx
          VALUES( '',NOW(),'lkp/消息中心/系统消息/YHXX',
          '','','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7',
         '11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',NOW(),
         '11e6-592b-e2cbed80-87e9-a7e317d86c1d',0,1,'11e5-d902-cd3e1cdb-bf5d-334818ab8704',
         0,'','','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467','{}','','','',openid0,id0,NOW(),TID) ; 
       
         INSERT INTO T_DOCUMENT  
      VALUES (TID,NOW(),'lkp/消息中心/系统消息/YHXX','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7',
      '11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',NOW(),'11e6-592b-e2cbed80-87e9-a7e317d86c1d',0,1,'',
      '11e5-d902-cd3e1cdb-bf5d-334818ab8704','','','','','','','',0,'11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
      '{}','','','',TID);
      
          INSERT INTO tbl_send_message_middle_table(openid,mid0) VALUES(openid0,id0);    
          UPDATE tlk_TSXX SET ITEM_COUNT=ITEM_COUNT+1 WHERE id=id0;
          
         END LOOP sale_loop;
       CLOSE sale_csr; 
          SELECT ITEM_IMGURL,ITEM_URL,ITEM_DETIAL,ITEM_XXBT,ID,CASE WHEN item_tzlx='微信' THEN 'wx'
                                                                                               ELSE 'zs' END ITEM_KIND FROM tlk_TSXX      
          WHERE item_mgstate=1 AND NOW() BETWEEN item_fromdate AND item_todate
          AND ITEM_MGCODE=mcode;
         -- AND id  IN (SELECT mid0  FROM tbl_send_message_middle_table
        --  WHERE openid=openid0);        
         
        DELETE FROM tbl_send_message_middle_table WHERE openid=openid0;
        SET @a=ROW_COUNT();   
          IF (err=1) THEN
             COMMIT; 
          ELSE 
            ROLLBACK;   
         END IF;   
   
END