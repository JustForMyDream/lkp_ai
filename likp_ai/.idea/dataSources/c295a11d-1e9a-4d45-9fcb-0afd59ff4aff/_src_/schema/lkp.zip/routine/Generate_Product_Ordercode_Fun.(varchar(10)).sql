CREATE FUNCTION `Generate_Product_Ordercode_Fun`(`kind` VARCHAR(10))
  RETURNS VARCHAR(20)
BEGIN
      DECLARE result VARCHAR(20);
      Set @firstdata='DDBH';
      set @seconddata=kind;
      set @thirddata= DATE_FORMAT(NOW(),'%Y%m%d');
      set @lengthdata=char_length(@firstdata)+CHAR_LENGTH(@seconddata)+CHAR_LENGTH(@thirddata);
      set @str=concat(@firstdata,@seconddata,@thirddata);
      SET @a=IFNULL((SELECT CONVERT(SUBSTRING(ITEM_DDBH,@lengthdata+1,4), UNSIGNED)  FROM tlk_ddxx    
    --  WHERE ITEM_orderid LIKE CONCAT(str,'%')
      ORDER BY created DESC LIMIT 0,1),0);
      IF (@a<9) THEN
         SET @a=@a+1; 
         SET result=CONCAT('000',CONVERT(@a, CHAR(4)));
      ELSEIF ((@a>=9) AND (@a<99) ) THEN
          SET @a=@a+1; 
          SET result=CONCAT('00',CONVERT(@a, CHAR(4))); 
      ELSEIF ((@a>=99) AND (@a<999)) THEN
         SET @a=@a+1; 
        SET result=CONCAT('0',CONVERT(@a, CHAR(4)));
      ELSE         
        SET @a=@a+1;
        SET result=CONVERT(@a, CHAR(4));     
      END IF;
     SET result=CONCAT(@str,result);
     RETURN  result;
    END