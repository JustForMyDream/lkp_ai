CREATE PROCEDURE `Search_ZPDS_Proc`(`ds`   VARCHAR(20), `js` VARCHAR(20), `ks` VARCHAR(20), `jssj` VARCHAR(20),
                                    `clzt` VARCHAR(10))
  BEGIN
       SELECT tlk_ddds.id,tlk_ddds.FORMID,tlk_ddds.DOMAINID,item_ddbh,item_cpmc,ITEM_DSJE
ITEM_DSYH,ITEM_JSYH,ITEM_DSZP,ITEM_DSSJ,ITEM_CLZT,ITEM_CLSJ,b.ITEM_NICKNAME AS ITEM_DSNAME,C.ITEM_NICKNAME AS ITEM_JSNAME FROM tlk_ddds INNER JOIN 
( SELECT item_ddbh,item_cpmc FROM   tlk_ddxx  INNER JOIN tlk_cpxx ON tlk_cpxx.ITEM_CPBH=ITEM_PSTC
  UNION
  SELECT ID AS item_ddbh,item_zpmc  AS item_cpmc FROM tlk_user_ps_data
  ) a   ON a.item_ddbh=tlk_ddds.ITEM_DSZP 
  INNER JOIN tlk_user_wx_info b
  ON b.ITEM_OPENID=ITEM_DSYH 
   INNER JOIN tlk_user_wx_info c
   ON c.ITEM_OPENID=ITEM_JSYH  where tlk_ddds.id<>'' 
   and b.ITEM_NICKNAME like concat('%',ds,'%')  
   AND c.ITEM_NICKNAME LIKE CONCAT('%',js,'%')
   AND  ITEM_CLZT   LIKE CONCAT('%',clzt,'%') 
   and  ( DATE_FORMAT(item_dssj,'%Y-%m-%d')>=ks
   or  DATE_FORMAT(item_dssj,'%Y-%m-%d')<=jssj);
  
    END