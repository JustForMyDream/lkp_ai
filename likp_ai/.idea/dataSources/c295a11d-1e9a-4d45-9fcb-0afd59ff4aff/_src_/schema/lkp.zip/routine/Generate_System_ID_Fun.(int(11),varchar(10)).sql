CREATE FUNCTION `Generate_System_ID_Fun`(`n` INT(11), `kind` VARCHAR(10))
  RETURNS VARCHAR(255)
BEGIN
     DECLARE return_str VARCHAR(255) DEFAULT '';
     SET return_str=CONCAT(DATE_FORMAT(NOW(),'%Y%m%d%H%m%s'),kind,Generate_Rand_String_Fun(n));  
     RETURN return_str;
    END