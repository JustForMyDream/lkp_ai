CREATE PROCEDURE `Insert_Product_Ordercode_Proc`(`xdyh` VARCHAR(50), `jdyh` VARCHAR(50), `pslx` VARCHAR(50),
                                                 `cpbh` VARCHAR(50), `psdd` VARCHAR(50), `psdj` FLOAT, `psrq` DATETIME,
                                                 `psrs` INT(11), `ddbz` VARCHAR(50))
  BEGIN
    
    /* 参数 
    xdyh   下单用户
    jdyh  接单用户
    pslx  拍摄类型
    cpbh  产品编号
    psdd  拍摄地点（景区名称） 
    psdj   产品单价
    psrq   拍摄日期
   psrs  拍摄人数 
   ddbz  订单备注
    返回值 result  订单编号
    */
         DECLARE err INT DEFAULT 1;#声明一个整形变量err，默认值是1
         DECLARE TID VARCHAR(30);
         SET TID=Generate_System_ID_Fun(4,'OID');
         SET @ab=Generate_Product_Ordercode_Fun('');
         START TRANSACTION;
          insert into tlk_ddxx values ('',now(),'lkp/订单管理/订单信息/DDXX','','','','11e5-f968-ad883d75-9fc8-3ff2b1b69382','11e1-81e2-37fe734a-9124-47aada6b7467',
          now(),'11e6-4a5b-93978a01-8c18-5dc694bf486d','(Binary/Image)',1,'11e6-4a4a-0642dfe5-8c18-5dc694bf486d',0,'','','','11e5-f968-ad883d75-9fc8-3ff2b1b69382',
          '11e1-81e2-37f74759-9124-47aada6b7467','{}','','','',@ab,xdyh,jdyh,pslx,cpbh,psdd,1,psdj,now(),psrq,1,TID,psrs,ddbz,'','');
          
          insert into t_document values (TID,now(),'lkp/订单管理/订单信息/DDXX','','11e5-f968-ad883d75-9fc8-3ff2b1b69382','11e1-81e2-37fe734a-9124-47aada6b7467',
          now(),'11e6-4a5b-93978a01-8c18-5dc694bf486d','(Binary/Image)',1,'','11e6-4a4a-0642dfe5-8c18-5dc694bf486d','','','','','','','',0,'11e5-f968-ad883d75-9fc8-3ff2b1b69382',
          '11e1-81e2-37f74759-9124-47aada6b7467','{}','','','',TID);
          
          
     IF (err=1) THEN
        SET result=CONCAT(@ab);
         COMMIT; 
     ELSE 
     SET result='0';
     ROLLBACK;   
     END IF;    
     select result;    
    END