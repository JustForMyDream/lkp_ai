CREATE FUNCTION `Calculate_Distance_Between_Points`(`FromLng` DECIMAL(12, 6), `FromLat` DECIMAL(12, 6),
                                                    `ToLng`   DECIMAL(12, 6), `ToLat` DECIMAL(12, 6))
  RETURNS DECIMAL(12, 4)
BEGIN
      DECLARE result DECIMAL(12,4);
      SET  result=6371.004*ACOS(SIN(FromLat/180*PI())*SIN(ToLat/180*PI())+
      COS(FromLat/180*PI())*COS(ToLat/180*PI())*COS((FromLng-ToLng)/180*PI()));
      RETURN  result;
    END