CREATE TRIGGER `Insert_CP_TP_Tri`
AFTER INSERT ON `tlk_cptp`
FOR EACH ROW
  BEGIN
   DECLARE err INT DEFAULT 1;#声明一个整形变量err，默认值是1
      DECLARE str NVARCHAR(8000);
      DECLARE str1 NVARCHAR(8000);
      DECLARE sub_str NVARCHAR(8000);
      DECLARE sub_str1 NVARCHAR(8000);
      DECLARE total_str NVARCHAR(8000);
      DECLARE total_str1 NVARCHAR(8000);
      DECLARE TID NVARCHAR(50);
      DECLARE p INT;
      DECLARE pp INT;
      DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET err=0;#当sqlexception handler捕捉到异常时，设置err=0    
      SET str=SUBSTRING(new.item_tp,2,CHAR_LENGTH(new.item_tp)-2);    
      SET p=LOCATE('}',str);     
      IF p=0 THEN             
          SET TID=Generate_System_ID_Fun(4,'MID');      
          INSERT INTO tlk_cptp_copy  VALUES (new.parent,NOW(),'lkp/产品管理/产品信息/CPTP_COPY','','','',
           '11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',
           NOW(),'11e6-4bcf-4405c0ce-8c18-5dc694bf486d',0,1,'11e6-4a4a-0642dfe5-8c18-5dc694bf486d',0,'','','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
           '{}','','','',new.item_tp,TID,new.item_sx);
           
             INSERT INTO T_DOCUMENT  
             VALUES (TID,NOW(),'lkp/产品管理/产品信息/CPTP_COPY','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7',
      '11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',NOW(),'11e6-4bcf-4405c0ce-8c18-5dc694bf486d',0,1,'',
      '11e6-4a4a-0642dfe5-8c18-5dc694bf486d','','','','','','','',0,'11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
      '{}','','','',TID);   
          
      
      ELSE
      
       lp1 : LOOP
       
       SET sub_str=SUBSTRING(str,1,p);           
       SET TID=Generate_System_ID_Fun(4,'MID');
       SET total_str=CONCAT('[',sub_str,']');
      INSERT INTO tlk_cptp_copy  VALUES (new.parent,NOW(),'lkp/产品管理/产品信息/CPTP_COPY','','','',
           '11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',
           NOW(),'11e6-4bcf-4405c0ce-8c18-5dc694bf486d',0,1,'11e6-4a4a-0642dfe5-8c18-5dc694bf486d',0,'','','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
           '{}','','','',total_str,TID,new.item_sx);
                   
             INSERT INTO T_DOCUMENT  
             VALUES (TID,NOW(),'lkp/产品管理/产品信息/CPTP_COPY','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7',
      '11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',NOW(),'11e6-4bcf-4405c0ce-8c18-5dc694bf486d',0,1,'',
      '11e6-4a4a-0642dfe5-8c18-5dc694bf486d','','','','','','','',0,'11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
      '{}','','','',TID);   
          
         SET str=SUBSTRING(str,p+2,CHAR_LENGTH(str)-p-1);
         SET p=LOCATE('}',str);
       
       IF p=0 THEN
          /* SET TID=Generate_System_ID_Fun(4,'MID');
          INSERT INTO tlk_tbl_ordercode_picture_select_detial_copy VALUES (new.parent,NOW(),'立可拍/数据中心/订单管理/tbl_ordercode_picture_select_detial','','','',
           '11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',
           NOW(),'11e5-f005-2879c6b9-9fc8-3ff2b1b69382',0,1,'11e5-d902-cd3e1cdb-bf5d-334818ab8704',0,'','','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
           '{}','','','',str,'否',TID);
           
             INSERT INTO T_DOCUMENT  
          VALUES (TID,NOW(),'立可拍/数据中心/订单管理/tbl_ordercode_picture_select_detial','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7',
      '11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',NOW(),'11e5-ece5-a2026512-9fc8-3ff2b1b69382',0,1,'',
      '11e5-d902-cd3e1cdb-bf5d-334818ab8704','','','','','','','',0,'11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
      '{}','','','',TID); 
      */ 
            
      
             LEAVE lp1;
           END IF;        
       END LOOP;      
    END IF; 
    END