CREATE TRIGGER `Insert_DDPJ_Tri`
AFTER INSERT ON `t_cxt_comment`
FOR EACH ROW
  BEGIN
              DECLARE err INT DEFAULT 1;#声明一个整形变量err，默认值是1
              DECLARE str NVARCHAR(8000);
              DECLARE TID NVARCHAR(50);
             SET TID=Generate_System_ID_Fun(4,'MID');      
          INSERT INTO tlk_ddpj  VALUES ('',NOW(),'lkp/订单管理/订单信息/DDPJ','','','',
           '11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',
           NOW(),'11e6-5e14-3ec91152-87ca-8d9ea8bd91fb',0,1,'11e6-4a4a-0642dfe5-8c18-5dc694bf486d',0,'','','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
           '{}','','','',new.item_ddbh,new.item_point,new.item_words,TID,new.item_btn);
           
             INSERT INTO T_DOCUMENT  
             VALUES (tid,NOW(),'lkp/订单管理/订单信息/DDPJ','','11e3-81b0-6e890f2c-95c1-e91b6587a8c7',
      '11e1-81e2-37fe734a-9124-47aada6b7467_11e1-81e2-714059a0-9124-47aada6b7467_11e1-81e2-cd25216a-9124-47aada6b7467',NOW(),'11e6-5e14-3ec91152-87ca-8d9ea8bd91fb',0,1,'',
      '11e6-4a4a-0642dfe5-8c18-5dc694bf486d','','','','','','','',0,'11e3-81b0-6e890f2c-95c1-e91b6587a8c7','11e1-81e2-37f74759-9124-47aada6b7467',
      '{}','','','',TID);   
    END